const express = require('express');
const app = express();
const port = 3000;
const dotenv = require('dotenv');
dotenv.config();
const mysql = require('mysql');
let tablename = "forza_centre";

const con = mysql.createPool({
    host: process.env.DB_HOST,
    port: process.env.DB_PORT,
    user: process.env.DB_USER,
    password: process.env.DB_PASS,
    database: process.env.DB_NAME
});

app.use(express.json());

app.get('/', (req, res) => res.send('Hello, world!'));

app.get('/showDBs', (req, res) => {
    con.getConnection(function(err) {
        if (err) throw err;
        con.query("SHOW DATABASES", function (err, result, fields) {
            if (err) throw err;
            console.log(result);
            res.json({
                databases: result
            })
        });
    });
});
class game {
    creatorUsername;
    players = [];
    price = null
    class = null;
    race = null;
    not_upgradeable = null
    gameStarted = false;
    constructor(creatorUsername) {
        this.creatorUsername = creatorUsername;
        this.players.push(creatorUsername);
    }
}

app.post('/creategame', (req, res) => {
    let creatorUsername = req.body.creatorUsername;

    let newGame = new game(creatorUsername);
    con.getConnection(function(err) {
        if (err) throw err;
        let playersString = JSON.stringify(newGame.players);
        let query = `INSERT INTO ${tablename} (price, class, race, not_upgradeable, players, gameStarted) VALUES (?, ?, ?, ?, ?, ?)`;
        let values = [newGame.price, newGame.class, newGame.race, newGame.not_upgradeable, playersString, newGame.gameStarted];
        // Run the query
        con.query(query, values, function (err, result, fields) {
            if (err) throw err;
            res.json({
                result: result,
                link: "https://roblox.com"
            })
        });
    })
})


app.listen(port, () => console.log(`Example app listening at http://localhost:${port}`));