const { SlashCommandBuilder } = require('discord.js');

module.exports = {
	data: new SlashCommandBuilder()
		.setName('start')
		.setDescription('Command used to start a game, will return a link to the game'),
	async execute(interaction) {
		// fetch /creategame with the user's username as post
        fetch('http://localhost:3000/creategame', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                creatorUsername: interaction.user.username
            })
        }).then(response => response.json()).then(data => {
            interaction.reply(data.link)
        })
	},
};